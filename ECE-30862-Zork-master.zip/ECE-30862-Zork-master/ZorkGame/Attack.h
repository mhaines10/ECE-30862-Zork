#ifndef ATTACK_H_
#define ATTACK_H_
#include <stdio.h>
using namespace std;
using namespace rapidxml;

